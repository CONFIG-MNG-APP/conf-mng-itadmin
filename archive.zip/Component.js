sap.ui.define(["sap/fe/core/AppComponent"],function(n){"use strict";return n.extend("zgsp26.conf.mng.itadmin.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map